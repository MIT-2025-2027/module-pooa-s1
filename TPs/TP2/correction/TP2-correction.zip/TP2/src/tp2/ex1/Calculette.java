package tp2.ex1;

public class Calculette {
	
	public void zero()
	{
		System.out.print("0");
	}
	
	public void un()
	{
		System.out.print("1");
	}
	
	public void deux()
	{
		System.out.print("2");
	}
	
	public void trois()
	{
		System.out.print("3");
	}

	public void quatre()
	{
		System.out.print("4");
	}
	
	public void cinq()
	{
		System.out.print("5");
	}
	
	public void six()
	{
		System.out.print("6");
	}
	
	public void sept()
	{
		System.out.print("7");
	}
	
	public void huit()
	{
		System.out.print("8");
	}
	
	public void neuf()
	{
		System.out.print("9");
	}
	
	public void mul()
	{
		System.out.print("x");
	}
	
	public void moins()
	{
		System.out.print("-");
	}

	public void plus()
	{
		System.out.print("+");
	}
	
	public void div()
	{
		System.out.print("/");
	}
	
	public void raz()
	{
		System.out.println("0");
	}
	
	public double getValue()
	{
		return 564 / 2;
	}
	
	public void dot()
	{
		System.out.print(".");
	}
	
	public void egal()
	{
		System.out.print("=");
	}
}
