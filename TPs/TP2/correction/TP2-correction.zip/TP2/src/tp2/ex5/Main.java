package tp2.ex5;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Complexe c1 = new Complexe(2.0, 5.5);
		
		System.out.println(c1.toString());

	}

}
